         <!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">

<html xmlns="http://www.w3.org/1999/xhtml">
    <head>
        <meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
        <meta name="viewport" content="width=device-width, initial-scale=1" />
        <title>NewHRMS</title>
        <link rel="stylesheet" href="<?php echo base_url();?>assets/css/bootstrap.min.css" />
        <link href="https://fonts.googleapis.com/css?family=Roboto:300,400,500,700" rel="stylesheet" />
        <link href="https://fonts.googleapis.com/css?family=Open+Sans:300,400,600" rel="stylesheet" />
        <link rel="stylesheet" type="text/css" href="<?php echo base_url();?>assets/css/font-awesome.min.css" />
        <link rel="stylesheet" href="<?php echo base_url();?>assets/css/transition.css" />
        <link rel="stylesheet" href="<?php echo base_url();?>assets/css/custom.css" />

    </head>

    <body>

        <div class="inner-wrapper thankyou-wrapper">

            <section class="welcome-block pad-41">
                <div class="container">
                    <div class="row">
                        <div class="col-lg-6 no-float center-block">
                            <div class="welcome-content mt-41 clearfix">
                                <div class="v-middle mt-41 text-center">
                                    <h3>Thanks for buying. You will be in contact soon for installation & configuration of HRMS product</h3>
                                
                                
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </section>
       
        </div>
		
	

        <script src="<?php echo base_url();?>assets/js/jquery-1.11.0.min.js"></script>
        <script src="<?php echo base_url();?>assets/js/bootstrap.min.js"></script>


<script type="text/javascript">
 setTimeout(function(){window.location = '<?php echo base_url();?>'; }, 3000);
</script>
    </body>
</html>
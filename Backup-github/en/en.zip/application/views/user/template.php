<?php
    
 

         $this->load->view($theme . '/modules/' . $module .'/'.$page);   
    
?>